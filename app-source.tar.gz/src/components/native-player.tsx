'use client';

import { useRef, useState } from 'react';

interface NativePlayerProps {
  url: string;
  title: string;
  getRestorePosition?: () => number | Promise<number>;
  onTimeUpdate?: (position: number, duration: number) => void;
  onPause?: (position: number, duration: number) => void;
  onEnded?: () => void;
}

/** Manual native HLS playback for mobile browsers whose custom player stalls. */
export function NativePlayer(props: NativePlayerProps) {
  // A new episode resets the video element, restore state and any previous error.
  return <NativeVideo key={props.url} {...props} />;
}

function NativeVideo({ url, title, getRestorePosition, onTimeUpdate, onPause, onEnded }: NativePlayerProps) {
  const videoRef = useRef<HTMLVideoElement>(null);
  const restoredRef = useRef(false);
  const lastSaveRef = useRef(0);
  const [error, setError] = useState('');
  // Keep manifests, segments and keys on the authenticated local origin.
  const mediaUrl = url.startsWith('/api/proxy') ? url : `/api/proxy?url=${encodeURIComponent(url)}`;

  return (
    <div className="relative w-full h-full bg-black">
      <video
        ref={videoRef}
        className="w-full h-full"
        src={mediaUrl}
        controls
        playsInline
        preload="metadata"
        aria-label={title}
        onLoadedMetadata={async () => {
          if (restoredRef.current) return;
          restoredRef.current = true;
          try {
            const saved = (await getRestorePosition?.()) ?? 0;
            const video = videoRef.current;
            if (video && saved > 10 && saved < video.duration - 2) video.currentTime = saved;
          } catch { /* Storage failures must not block playback. */ }
        }}
        onTimeUpdate={(event) => {
          if (Date.now() - lastSaveRef.current < 5000) return;
          lastSaveRef.current = Date.now();
          const video = event.currentTarget;
          onTimeUpdate?.(video.currentTime, video.duration);
        }}
        onPause={(event) => {
          const video = event.currentTarget;
          if (!video.ended) onPause?.(video.currentTime, video.duration);
        }}
        onEnded={onEnded}
        onPlaying={() => setError('')}
        onError={(event) => {
          const code = event.currentTarget.error?.code;
          setError(code === 3 || code === 4
            ? '当前浏览器无法播放这个视频格式，请尝试标准播放或其他浏览器。'
            : '视频加载失败，请重新登录后刷新，或尝试其他点播源。');
        }}
      />
      {error && <p role="alert" className="absolute inset-x-0 top-0 p-3 text-sm text-white bg-black/80">{error}</p>}
    </div>
  );
}
